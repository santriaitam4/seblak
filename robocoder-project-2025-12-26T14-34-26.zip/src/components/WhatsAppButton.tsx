"use client";

import { MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

interface WhatsAppButtonProps {
  message?: string;
  phoneNumber?: string;
  className?: string;
  children?: React.ReactNode;
  size?: "default" | "sm" | "lg" | "icon";
}

export default function WhatsAppButton({ 
  message = "Halo, saya ingin memesan seblak", 
  phoneNumber = "6281234567890",
  className = "",
  children,
  size = "default"
}: WhatsAppButtonProps) {
  const handleWhatsAppClick = () => {
    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <Button 
      onClick={handleWhatsAppClick}
      size={size}
      className={`bg-green-600 hover:bg-green-700 text-white ${className}`}
    >
      <MessageCircle className="w-4 h-4 mr-2" />
      {children || "Chat WhatsApp"}
    </Button>
  );
}
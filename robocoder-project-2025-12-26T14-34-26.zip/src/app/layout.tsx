import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Warung Seblak Bu Sari - Seblak Pedas Mantap di Jakarta",
  description: "Warung Seblak Bu Sari menyajikan seblak pedas terenak di Jakarta. Berbagai varian seblak dengan level kepedasan sesuai selera. Pesan sekarang juga!",
  keywords: "seblak, warung seblak, makanan pedas, seblak jakarta, seblak enak, kuliner indonesia",
  authors: [{ name: "Warung Seblak Bu Sari" }],
  openGraph: {
    title: "Warung Seblak Bu Sari - Seblak Pedas Mantap",
    description: "Seblak pedas terenak di Jakarta dengan berbagai varian dan level kepedasan",
    type: "website",
    locale: "id_ID",
  },
  robots: {
    index: true,
    follow: true,
  },
  viewport: "width=device-width, initial-scale=1",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="id" className="scroll-smooth">
      <body className={`${inter.className} antialiased`}>
        {children}
      </body>
    </html>
  );
}
"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, MapPin, Clock, Phone, MessageCircle, ChefHat, Flame } from "lucide-react";
import WhatsAppButton from "@/components/WhatsAppButton";
import ScrollToTop from "@/components/ScrollToTop";

export default function HomePage() {
  const [selectedLevel, setSelectedLevel] = useState("sedang");

  const menuItems = [
    {
      id: 1,
      name: "Seblak Original",
      price: "Rp 15.000",
      description: "Seblak klasik dengan kerupuk, telur, dan sayuran segar",
      image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/cadf8caa-9af7-484d-8568-099649b2a988.png",
      level: "sedang",
      popular: true
    },
    {
      id: 2,
      name: "Seblak Seafood",
      price: "Rp 25.000",
      description: "Seblak dengan udang, cumi, dan bakso ikan segar",
      image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/b509dcbc-a30f-4c6c-963e-c241dd292f40.png",
      level: "pedas",
      popular: false
    },
    {
      id: 3,
      name: "Seblak Komplit",
      price: "Rp 20.000",
      description: "Seblak lengkap dengan sosis, nugget, dan keju mozarella",
      image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/fb56f004-d838-4548-afed-e6b34ba8edd6.png",
      level: "sedang",
      popular: true
    },
    {
      id: 4,
      name: "Seblak Pedas Mantap",
      price: "Rp 18.000",
      description: "Seblak super pedas untuk pecinta cabai level dewa",
      image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/5c19938f-0c32-4a4a-a427-3419588164df.png",
      level: "sangat-pedas",
      popular: false
    },
    {
      id: 5,
      name: "Seblak Keju",
      price: "Rp 22.000",
      description: "Seblak creamy dengan keju leleh dan topping premium",
      image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/2300c80e-41d4-45b4-b2f7-37d391f46428.png",
      level: "ringan",
      popular: true
    },
    {
      id: 6,
      name: "Seblak Ayam Geprek",
      price: "Rp 23.000",
      description: "Seblak dengan ayam geprek crispy dan sambal terasi",
      image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/5a193c98-cbfe-48ac-b937-22519de41ec3.png",
      level: "pedas",
      popular: false
    }
  ];

  const testimonials = [
    {
      name: "Andi Pratama",
      rating: 5,
      comment: "Seblaknya enak banget! Pedasnya pas dan porsinya besar. Recommended!",
      image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/f5842846-2335-4262-b5ed-37eb9689e6f9.png"
    },
    {
      name: "Siti Nurhaliza",
      rating: 5,
      comment: "Udah langganan di sini. Seblak seafoodnya fresh dan bumbu meresap sempurna.",
      image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/4e2fe748-e73a-4220-ab33-78d368d88fc0.png"
    },
    {
      name: "Budi Santoso",
      rating: 4,
      comment: "Tempatnya bersih, pelayanan ramah. Seblak keju favoritku!",
      image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/698b03f6-3c4b-418a-9245-b97604e93880.png"
    }
  ];

  const getLevelColor = (level: string) => {
    switch (level) {
      case "ringan": return "bg-green-100 text-green-800";
      case "sedang": return "bg-yellow-100 text-yellow-800";
      case "pedas": return "bg-orange-100 text-orange-800";
      case "sangat-pedas": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getLevelIcon = (level: string) => {
    switch (level) {
      case "ringan": return "🟢";
      case "sedang": return "🟡";
      case "pedas": return "🟠";
      case "sangat-pedas": return "🔴";
      default: return "⚪";
    }
  };

  const filteredMenu = selectedLevel === "semua" 
    ? menuItems 
    : menuItems.filter(item => item.level === selectedLevel);

  return (
    <div className="min-h-screen bg-gradient-to-b from-red-50 to-orange-50">
      {/* Header */}
      <header className="bg-white shadow-lg sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-r from-red-600 to-orange-600 rounded-full flex items-center justify-center">
                <ChefHat className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-red-600">Warung Seblak</h1>
                <p className="text-sm text-gray-600">Bu Sari</p>
              </div>
            </div>
            <nav className="hidden md:flex space-x-6">
              <a href="#home" className="text-gray-700 hover:text-red-600 transition-colors">Beranda</a>
              <a href="#menu" className="text-gray-700 hover:text-red-600 transition-colors">Menu</a>
              <a href="#tentang" className="text-gray-700 hover:text-red-600 transition-colors">Tentang</a>
              <a href="#kontak" className="text-gray-700 hover:text-red-600 transition-colors">Kontak</a>
            </nav>
            <WhatsAppButton 
              message="Halo, saya ingin memesan seblak dari website"
              className="bg-red-600 hover:bg-red-700"
            >
              Pesan Sekarang
            </WhatsAppButton>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section id="home" className="relative py-20 bg-gradient-to-r from-red-600 to-orange-600 text-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-5xl font-bold mb-6 leading-tight">
                Seblak Pedas<br />
                <span className="text-yellow-300">Mantap Jiwa!</span>
              </h2>
              <p className="text-xl mb-8 text-red-100">
                Nikmati kelezatan seblak autentik dengan bumbu rempah pilihan dan level kepedasan sesuai selera Anda. 
                Dibuat dengan cinta oleh Bu Sari sejak 2015.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold">
                  <MessageCircle className="w-5 h-5 mr-2" />
                  Pesan via WhatsApp
                </Button>
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-red-600">
                  Lihat Menu
                </Button>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/bc2178e1-8f34-47c4-92af-2d1f0bd57ce9.png" 
                alt="Seblak pedas mantap dengan topping lengkap"
                className="rounded-2xl shadow-2xl w-full"
              />
              <div className="absolute -bottom-6 -left-6 bg-yellow-400 text-black p-4 rounded-xl shadow-lg">
                <div className="flex items-center space-x-2">
                  <Star className="w-5 h-5 fill-current" />
                  <span className="font-bold">4.9/5</span>
                </div>
                <p className="text-sm">1000+ Review</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Menu Section */}
      <section id="menu" className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h3 className="text-4xl font-bold text-gray-800 mb-4">Menu Seblak Kami</h3>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Pilihan seblak terlengkap dengan berbagai topping dan level kepedasan sesuai selera
            </p>
          </div>

          {/* Filter Level Kepedasan */}
          <div className="flex flex-wrap justify-center gap-3 mb-12">
            {["semua", "ringan", "sedang", "pedas", "sangat-pedas"].map((level) => (
              <Button
                key={level}
                variant={selectedLevel === level ? "default" : "outline"}
                onClick={() => setSelectedLevel(level)}
                className={`${selectedLevel === level ? "bg-red-600 hover:bg-red-700" : "hover:bg-red-50"}`}
              >
                <Flame className="w-4 h-4 mr-2" />
                {level === "semua" ? "Semua" : 
                 level === "ringan" ? "Ringan" :
                 level === "sedang" ? "Sedang" :
                 level === "pedas" ? "Pedas" : "Sangat Pedas"}
              </Button>
            ))}
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredMenu.map((item) => (
              <Card key={item.id} className="overflow-hidden hover:shadow-xl transition-shadow duration-300">
                <div className="relative">
                  <img 
                    src={item.image} 
                    alt={item.name}
                    className="w-full h-48 object-cover"
                  />
                  {item.popular && (
                    <Badge className="absolute top-3 left-3 bg-yellow-500 text-black">
                      Populer
                    </Badge>
                  )}
                  <Badge className={`absolute top-3 right-3 ${getLevelColor(item.level)}`}>
                    {getLevelIcon(item.level)} {item.level.charAt(0).toUpperCase() + item.level.slice(1).replace("-", " ")}
                  </Badge>
                </div>
                <CardContent className="p-6">
                  <h4 className="text-xl font-bold text-gray-800 mb-2">{item.name}</h4>
                  <p className="text-gray-600 mb-4">{item.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-red-600">{item.price}</span>
                    <WhatsAppButton 
                      message={`Halo, saya ingin memesan ${item.name} (${item.price}). Apakah tersedia?`}
                      className="bg-red-600 hover:bg-red-700"
                    >
                      Pesan
                    </WhatsAppButton>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="tentang" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-4xl font-bold text-gray-800 mb-6">Tentang Warung Seblak Bu Sari</h3>
              <p className="text-lg text-gray-600 mb-6">
                Sejak 2015, Warung Seblak Bu Sari telah menjadi destinasi favorit pecinta kuliner pedas di Jakarta. 
                Dimulai dari gerobak kecil, kini kami telah melayani ribuan pelanggan dengan resep rahasia turun temurun.
              </p>
              <p className="text-lg text-gray-600 mb-8">
                Kami menggunakan bahan-bahan segar pilihan dan bumbu rempah asli Indonesia untuk menciptakan cita rasa 
                seblak yang autentik dan tak terlupakan. Setiap mangkuk seblak dibuat dengan penuh cinta dan perhatian.
              </p>
              <div className="grid grid-cols-2 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-red-600">8+</div>
                  <div className="text-gray-600">Tahun Pengalaman</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-red-600">10K+</div>
                  <div className="text-gray-600">Pelanggan Puas</div>
                </div>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/e077bfe9-a5f9-4846-a52e-1582af5b1def.png" 
                alt="Suasana warung seblak Bu Sari yang nyaman"
                className="rounded-2xl shadow-xl w-full"
              />
              <div className="absolute -bottom-6 -right-6 bg-red-600 text-white p-6 rounded-xl shadow-lg">
                <h4 className="font-bold text-lg">Resep Rahasia</h4>
                <p className="text-sm text-red-100">Turun Temurun</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h3 className="text-4xl font-bold text-gray-800 mb-4">Kata Pelanggan Kami</h3>
            <p className="text-xl text-gray-600">Kepuasan pelanggan adalah prioritas utama kami</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center mb-4">
                  <img 
                    src={testimonial.image} 
                    alt={`Foto ${testimonial.name}`}
                    className="w-12 h-12 rounded-full mr-4"
                  />
                  <div>
                    <h4 className="font-semibold text-gray-800">{testimonial.name}</h4>
                    <div className="flex">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 italic">"{testimonial.comment}"</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="kontak" className="py-20 bg-red-600 text-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-4xl font-bold mb-6">Kunjungi Warung Kami</h3>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <MapPin className="w-6 h-6 mt-1 text-yellow-300" />
                  <div>
                    <h4 className="font-semibold text-lg">Alamat</h4>
                    <p className="text-red-100">
                      Jl. Raya Seblak No. 123<br />
                      Kelurahan Pedas, Jakarta Selatan<br />
                      DKI Jakarta 12345
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <Clock className="w-6 h-6 mt-1 text-yellow-300" />
                  <div>
                    <h4 className="font-semibold text-lg">Jam Operasional</h4>
                    <p className="text-red-100">
                      Senin - Minggu: 10.00 - 22.00 WIB<br />
                      Buka setiap hari
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <Phone className="w-6 h-6 mt-1 text-yellow-300" />
                  <div>
                    <h4 className="font-semibold text-lg">Kontak</h4>
                    <p className="text-red-100">
                      Telepon: (021) 1234-5678<br />
                      WhatsApp: +62 812-3456-7890
                    </p>
                  </div>
                </div>
              </div>
              <div className="mt-8">
                <WhatsAppButton 
                  message="Halo Bu Sari, saya ingin bertanya tentang lokasi dan jam operasional warung seblak"
                  size="lg"
                >
                  Chat WhatsApp Sekarang
                </WhatsAppButton>
              </div>
            </div>
            <div className="bg-white rounded-2xl p-2">
              <img 
                src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/0af8dbfb-a3d0-4ab1-92c3-380a5a09baf0.png" 
                alt="Peta lokasi Warung Seblak Bu Sari"
                className="w-full h-80 object-cover rounded-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-gradient-to-r from-red-600 to-orange-600 rounded-full flex items-center justify-center">
                  <ChefHat className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h4 className="text-xl font-bold">Warung Seblak Bu Sari</h4>
                </div>
              </div>
              <p className="text-gray-400">
                Seblak pedas terenak di Jakarta dengan cita rasa autentik dan pelayanan terbaik sejak 2015.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Menu Populer</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Seblak Original</li>
                <li>Seblak Seafood</li>
                <li>Seblak Komplit</li>
                <li>Seblak Keju</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Kontak Kami</h4>
              <div className="space-y-2 text-gray-400">
                <p>Jl. Raya Seblak No. 123, Jakarta Selatan</p>
                <p>Telepon: (021) 1234-5678</p>
                <p>WhatsApp: +62 812-3456-7890</p>
                <p>Email: info@warungseblakbusari.com</p>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Warung Seblak Bu Sari. Semua hak cipta dilindungi.</p>
          </div>
        </div>
      </footer>
      
      {/* Scroll to Top Button */}
      <ScrollToTop />
    </div>
  );
}
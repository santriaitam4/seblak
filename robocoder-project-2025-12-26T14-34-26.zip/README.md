# 🌶️ Website Warung Seblak Bu Sari

Website modern dan responsif untuk Warung Seblak Bu Sari - destinasi seblak pedas terenak di Jakarta sejak 2015.

## 🚀 Demo Live

Website dapat diakses di: [https://sb-79rh723rr9p6.vercel.run](https://sb-79rh723rr9p6.vercel.run)

## ✨ Fitur Utama

### 🎨 **Design Modern**
- Design responsif untuk semua perangkat (mobile, tablet, desktop)
- Warna tema merah-orange yang menarik dan sesuai dengan branding seblak
- Typography yang mudah dibaca dengan font Inter
- Animasi smooth dan hover effects

### 🍜 **Menu Seblak Lengkap**
- 6 varian seblak dengan foto AI-generated yang menarik
- Filter berdasarkan level kepedasan (Ringan, Sedang, Pedas, Sangat Pedas)
- Badge populer untuk menu favorit
- Harga dan deskripsi lengkap setiap menu

### 📱 **Integrasi WhatsApp**
- Tombol WhatsApp terintegrasi di seluruh website
- Pesan otomatis sesuai konteks (menu, kontak, dll)
- Nomor WhatsApp: +62 812-3456-7890

### 🏪 **Informasi Warung**
- Cerita tentang warung sejak 2015
- Alamat lengkap dan jam operasional
- Testimoni pelanggan dengan rating bintang
- Peta lokasi visual

### 🔧 **Fitur Teknis**
- SEO optimized dengan meta tags lengkap
- Performance tinggi dengan Next.js 15
- Scroll to top button
- Smooth scrolling navigation
- Loading yang cepat

## 🛠️ Teknologi yang Digunakan

- **Framework**: Next.js 15 dengan App Router
- **Styling**: Tailwind CSS + shadcn/ui components
- **Icons**: Lucide React
- **Font**: Inter (Google Fonts)
- **Images**: AI-generated images dengan konteks seblak Indonesia
- **Deployment**: Vercel

## 📋 Menu Seblak

| Menu | Harga | Level Pedas | Deskripsi |
|------|-------|-------------|-----------|
| Seblak Original | Rp 15.000 | Sedang | Seblak klasik dengan kerupuk, telur, dan sayuran segar |
| Seblak Seafood | Rp 25.000 | Pedas | Seblak dengan udang, cumi, dan bakso ikan segar |
| Seblak Komplit | Rp 20.000 | Sedang | Seblak lengkap dengan sosis, nugget, dan keju mozarella |
| Seblak Pedas Mantap | Rp 18.000 | Sangat Pedas | Seblak super pedas untuk pecinta cabai level dewa |
| Seblak Keju | Rp 22.000 | Ringan | Seblak creamy dengan keju leleh dan topping premium |
| Seblak Ayam Geprek | Rp 23.000 | Pedas | Seblak dengan ayam geprek crispy dan sambal terasi |

## 📍 Informasi Warung

**Alamat:**
```
Jl. Raya Seblak No. 123
Kelurahan Pedas, Jakarta Selatan
DKI Jakarta 12345
```

**Jam Operasional:**
- Senin - Minggu: 10.00 - 22.00 WIB
- Buka setiap hari

**Kontak:**
- Telepon: (021) 1234-5678
- WhatsApp: +62 812-3456-7890
- Email: info@warungseblakbusari.com

## 🚀 Cara Menjalankan Lokal

1. **Clone repository**
   ```bash
   git clone <repository-url>
   cd warung-seblak-website
   ```

2. **Install dependencies**
   ```bash
   pnpm install
   ```

3. **Jalankan development server**
   ```bash
   pnpm run dev
   ```

4. **Build untuk production**
   ```bash
   pnpm run build
   pnpm start
   ```

## 📱 Cara Memesan

### Via WhatsApp
1. Klik tombol "Pesan via WhatsApp" di website
2. Pilih menu yang diinginkan
3. Tentukan level kepedasan
4. Konfirmasi pesanan dengan Bu Sari

### Via Telepon
- Hubungi: (021) 1234-5678
- Sebutkan menu dan level kepedasan yang diinginkan

### Datang Langsung
- Kunjungi warung di Jl. Raya Seblak No. 123, Jakarta Selatan
- Buka setiap hari pukul 10.00 - 22.00 WIB

## 🎯 Target Audience

- Pecinta makanan pedas
- Mahasiswa dan pekerja muda
- Keluarga yang suka kuliner Indonesia
- Wisatawan yang ingin mencoba seblak autentik

## 🏆 Keunggulan Warung Seblak Bu Sari

- ✅ **8+ tahun pengalaman** sejak 2015
- ✅ **10.000+ pelanggan puas** dengan rating 4.9/5
- ✅ **Resep rahasia turun temurun** dengan bumbu rempah pilihan
- ✅ **Bahan segar** dipilih setiap hari
- ✅ **Level kepedasan** dapat disesuaikan
- ✅ **Harga terjangkau** mulai dari Rp 15.000
- ✅ **Pelayanan ramah** dan tempat bersih

## 📊 Performance

- ⚡ **Fast Loading**: Optimized untuk loading cepat
- 📱 **Mobile First**: Design responsif untuk semua perangkat
- 🔍 **SEO Friendly**: Meta tags dan structured data lengkap
- ♿ **Accessible**: ARIA labels dan keyboard navigation

## 🤝 Kontribusi

Website ini dibuat dengan cinta untuk Warung Seblak Bu Sari. Untuk saran dan masukan, silakan hubungi:
- Email: info@warungseblakbusari.com
- WhatsApp: +62 812-3456-7890

## 📄 Lisensi

© 2024 Warung Seblak Bu Sari. Semua hak cipta dilindungi.

---

**Dibuat dengan ❤️ untuk pecinta seblak Indonesia**
